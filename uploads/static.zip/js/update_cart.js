var updateBtns = document.getElementsByClassName('update-cart');
for (i = 0; i < updateBtns.length; i++) 
{
	updateBtns[i].addEventListener('click', function()
	{	
		var productId = this.dataset.product;
		console.log('productId', productId);

		var action = this.dataset.action;
		console.log('productId:', productId, 'Action:', action);

		eventactions(productId,action);
		location.reload()
		
	})
}

var clearBtn = document.getElementsByClassName("clearbutton"); //update-cart confused the buttons, made separate class name in main.css
for (i = 0; i < clearBtn.length; i++) 
{
    clearBtn[i].addEventListener('click', function()
    {	
        var action = this.dataset.action;
        
        try{productId=this.dataset.product}
        catch{productId = 0};

		eventactions(productId,action);
		location.reload();
	})
}


var nvs
var clear_ots = document.getElementsByClassName("clear_ots"); 
for (i = 0; i < clear_ots.length; i++) 
{
    clear_ots[i].addEventListener('click', function()
    {	


		removeitemsoutofstock()
		document.cookie='cart=' + JSON.stringify(cart) + ";domain=;path=/" + ";SameSite=Lax";
		console.log('Cookie Updated')
		location.reload();
	})
}

function addCookieItem(productId, action)
{
	if(action=='add')
	{
		console.log(cart[productId]);
		if(cart[productId] == undefined)
		{
			cart[productId]={'quantity':0};
			cart[productId]['quantity'] += 1;
		}
		else
		{
			cart[productId]['quantity'] += 1;
		};
		
	}
	else if(action=='remove')
	{
		cart[productId]['quantity'] -= 1;

		if(cart[productId]['quantity'] <=0 || undefined)
		{
			console.log('Remove item');
			delete cart[productId];
		}	
	}
	else if(action=='clear')
	{
		var cartstr=JSON.stringify(cart)
		if(cartstr != "{}" ){
			cart={};
			console.log('Cart Deleted');
		}
		else if(cartstr == "{}"){
			console.log('Cart is already empty');
		}
	}
	
	document.cookie='cart=' + JSON.stringify(cart) + ";domain=;path=/" + ";SameSite=Lax";

	console.log('Cookie Updated');
}

function updateUserOrder(productId, action)
{
	console.log('Authenicated User: Sending data...')

		var url = '/store/update_item/';

		fetch(url, 
		{
			
			method:'POST',
			headers:
				{
				'Content-Type':'application/json',
				'X-CSRFToken': csrftoken	
				}, 
			body:JSON.stringify({'productId':productId, 'action':action})
		})
		.then((response) => 
		{
		   return response.json();
		})
		.then((data) => 
		{
			console.log('data: ', data);
		})
	
}	

 //dead for now, need to import variable from cart page using getdocumentbyid

function removeitemsoutofstock()
{	var newvsold = JSON.parse(document.getElementById("newvsold").value);

	console.log(newvsold)
	for(nvs in newvsold)
	{
		console.log(nvs, 'Please Bro');
		delete cart[newvsold[nvs]];
		
	}
}

function eventactions(productId,action)
{
	if (user == 'AnonymousUser')
	{
		console.log('Guest User');
		addCookieItem(productId, action);
	}
	else
	{
		console.log('User is logged in.');
		addCookieItem(productId,action);
		updateUserOrder(productId, action);
	}
}


