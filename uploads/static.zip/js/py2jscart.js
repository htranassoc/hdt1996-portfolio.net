if(user!='AnonymousUser'){var itemsjson = document.getElementById("itemsCk").value}
else if(user=='AnonymousUser'){var itemsjson = document.getElementById("items").value}

//console.log(itemsjson, 'This is items from Python');

imgtypes=['png','jpg','jpeg','png','jfif'];
var i;

if(itemsjson ==''){console.log('Exiting Function')}
else{}
var imgs;
var itemsjson=itemsjson.split('&#x27;').join('"').split('{"id"').join('[{"id"').split('(').join('').split(')').join('').split('Decimal').join('') //cleanup singular string to create dictionary

for(imgi in imgtypes)
    {
        itemsjson=itemsjson.split("."+imgtypes[imgi]+'"}').join("."+imgtypes[imgi]+'"');

    }
//console.log(itemsjson,1);
//console.log(itemsjson,2);
itemsjson=itemsjson.split("},").join(',');
//console.log(itemsjson,3);
itemsjson=itemsjson.split(", {'prod").join("}} ,{'prod");
itemsjson=itemsjson.split('}]').join('}}]');
itemsjson=itemsjson.split("'").join('"')
//console.log(itemsjson,4);
try
{
    
        
        var itemsdict=JSON.parse(itemsjson);
        //console.log(itemsdict,'YO')
        
        for(i in itemsdict)
        {
            var y = itemsdict[i]['product']['productindex']
            itemname=itemsdict[i]['product']['name']; //itemsdict is nested dictionary, hence the [0]
            if(itemname == "Out of Stock")              
            {
                document.getElementById(itemname+'uparrow'+y).style.visibility="hidden";
                document.getElementById(itemname+'downarrow'+y).style.visibility="hidden";
                //document.getElementById(itemname+'numquantity'+y).style.visibility="hidden";
                //document.getElementById(itemname+'total'+y).style.visibility="hidden"
            }

            else
            {
                null
            }
        }
    
}

catch
{
    console.log('Parse String Error. Check Formulas and product attributes on cookiecart function in utils.')
}

